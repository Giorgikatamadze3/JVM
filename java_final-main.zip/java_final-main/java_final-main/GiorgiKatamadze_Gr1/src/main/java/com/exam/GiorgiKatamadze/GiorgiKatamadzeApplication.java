package com.exam.DianaRtveladze;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DianaRtveladzeApplication {

	public static void main(String[] args) {
		SpringApplication.run(DianaRtveladzeApplication.class, args);
	}

}
