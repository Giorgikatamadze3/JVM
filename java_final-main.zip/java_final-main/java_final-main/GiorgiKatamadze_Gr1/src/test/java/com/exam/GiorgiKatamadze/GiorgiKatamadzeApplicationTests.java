package com.exam.DianaRtveladze;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DianaRtveladzeApplicationTests {

	@Test
	void contextLoads() {
	}

}
